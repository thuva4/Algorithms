function unaryCoding(number)
{
    return Array(number+1).join("1")+'0';
}

