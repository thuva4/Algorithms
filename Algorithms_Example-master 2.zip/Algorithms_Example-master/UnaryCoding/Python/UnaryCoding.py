def unaryCoding(number):
  return ('1' * number) + '0'
