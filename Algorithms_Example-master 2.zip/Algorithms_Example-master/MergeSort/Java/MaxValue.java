public interface MaxValue<T>
{
    public T getMaxObject();
}
